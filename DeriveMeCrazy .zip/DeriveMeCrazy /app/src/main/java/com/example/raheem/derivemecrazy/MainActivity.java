package com.example.raheem.derivemecrazy;


//fix multiple decimal points
//fix ability to put no 0 in front of decimal
//remove old variables that aren't needed
//make UI look better
//add ans to history if normal math without variables (modify enter())

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.Stack;




public class MainActivity extends AppCompatActivity {
    private final static String TAG = MainActivity.class.getName();

    public ArrayList<String> oldEqns = new ArrayList<String>(10);

    //keeps track so that each number can have a max of 1 decimal in it
    public boolean decimal;

    public static double curAnswer = 0;
    public static String curSign = "";
    //What the user sees
    public String display = "";
    //Text on the current button
    private String buttonText = "";
    //for infix to postfix implementation, holds the last number typed by user
    private String curNum = "";

    private String[] postFix = new String[50];
    //to keep track of how many things have been put in postFix array
    private int idxCount = 0;
    private Stack operatorStack = new Stack();
    String history = "";
    //are we seeing the first character in expression?
    private boolean isFirst = true;
    //doesnt allow user to input 2 operations in a row
    public boolean isOperator = false;
    //makes sure user doesnt try to use the stored number after clearing
    public boolean wasCleared = true;
    //doesnt allow user to press enter twice without having numbers in equation
    //public boolean wasEntered = true;

    public int numLeftParen = 0;
    public int numRightParen = 0;
    ArrayList<String> infixEq = new ArrayList<String>();

    String[] finalEquation;

    //one case not handles: single decimal point
    //backspace for x doesn't work

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView tv = (TextView) findViewById(R.id.display);
        Bundle bundle = getIntent().getExtras();
        if (bundle==null){
            tv.setText("enter equation");

        }
        else{
            String displayEq = bundle.getString("display");
            tv.setText(displayEq);

        }

        if (savedInstanceState != null) {
            //restores all necessary values
            oldEqns = savedInstanceState.getStringArrayList("oldEqns");
            display = savedInstanceState.getString("display");
            decimal = savedInstanceState.getBoolean("decimal");
            curAnswer = savedInstanceState.getDouble("curAnswer");
            curSign = savedInstanceState.getString("curSign");
            buttonText = savedInstanceState.getString("buttonText");
            curNum = savedInstanceState.getString("curNum");
            postFix = savedInstanceState.getStringArray("postFix");
            idxCount = savedInstanceState.getInt("idxCount");
            isFirst = savedInstanceState.getBoolean("isFirst");
            isOperator = savedInstanceState.getBoolean("isOperator");
            wasCleared = savedInstanceState.getBoolean("wasCleared");
            //wasEntered = savedInstanceState.getBoolean("wasEntered");
            tv.setText(display);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putStringArrayList("oldEqns", oldEqns);
        savedInstanceState.putString("display", display);
        savedInstanceState.putBoolean("decimal", decimal);
        savedInstanceState.putDouble("curAnswer", curAnswer);
        savedInstanceState.putString("curSign", curSign);
        savedInstanceState.putString("buttonText", buttonText);
        savedInstanceState.putString("curNum", curNum);
        savedInstanceState.putStringArray("postFix", postFix);
        savedInstanceState.putInt("idxCount", idxCount);
        savedInstanceState.putBoolean("isFirst", isFirst);
        savedInstanceState.putBoolean("isOperator", isOperator);
        savedInstanceState.putBoolean("wasCleared", wasCleared);
        //savedInstanceState.putBoolean("wasEntered",wasEntered);
    }

    public void setActivityBackgroundColor(int color) {
        View view = this.getWindow().getDecorView();
        view.setBackgroundColor(color);
    }

    /***********************************************************************
     * checkString() -> tells whether inputted string is valid equation
     * call when calculate is hit. Return bool based on whether equation is valid.
     *  finalEquation is String[] of infix. If false, finalEquation is empty
     **************************************************************************/
    public void onButton(View v){
        TextView tv = (TextView) findViewById(R.id.display);
        Button b = (Button) v;
        buttonText = b.getText().toString();
        display+=buttonText;
        tv.setText(display);

    }

    public boolean checkString() {
        String num = "";
        ArrayList<String> operators = new ArrayList<String>(Arrays.asList("+", "-", "/", "*", "^"));
        ArrayList<String> numerics = new ArrayList<String>(Arrays.asList(".", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"));
        ArrayList<String> operands = new ArrayList<String>(Arrays.asList(".", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "x", "π", "e"));
        ArrayList<String> equation = new ArrayList<>();
        boolean hasNum = false;
        int numLParen = 0;
        int numRParen = 0;
        int i = 0;
        while (i < display.length()) {
            Log.d(TAG,"i: "+i+" "+display.substring(i,i+1));
            String symbol = display.substring(i, i + 1);
            if (numerics.contains(symbol)) { //numbers
                if (num.length()==0 && i>0 && operands.contains(display.substring(i - 1, i)) ){
                    Log.d(TAG,"Invalid Input 1");
                    finalEquation = new String[]{};
                    return false;
                }
                if(num.contains(".")&&symbol.equals(".")){
                    finalEquation = new String[]{};
                    return false;
                }
                hasNum=true;
                num += symbol;
                i++;

            } else if (symbol.equals("\u03C0") || symbol.equals("\u0065") || symbol.equals("x")) {
                if (i>0 && (operands.contains (display.substring(i - 1, i))|| display.substring(i - 1, i).equals(")") )) {
                    if (num.length() > 0) { //if its a number before (otherwise pi, e, or x)
                        equation.add(num);
                        num = "";
                        equation.add("*");
                        hasNum=true;
                    }
                }

                equation.add(symbol);
                i++;


            } else if (symbol.equals("s") || symbol.equals("c") || symbol.equals("t") || symbol.equals("l")) {  //trig and logs
                if (num.length() > 0) {
                    equation.add(num);
                    equation.add("*");
                    num = "";
                } else if (i>0 && (operands.contains(display.substring(i-1, i)) || display.substring(i-1, i).equals(")") )){
                    equation.add("*");
                }
                numLParen+=1;
                equation.add(display.substring(i, i + 3)); //add function
                equation.add(display.substring(i+3,i+4));   //add parenthesis
                i += 4;
            } else if (operators.contains(symbol)) { //operators

                if (symbol.equals("-") && (i == 0 || operators.contains(display.substring(i - 1, i)))) { //check if negative sign
                    num = "-";
                    i += 1;
                } else if (i == 0 || (i > 0 && display.substring(i - 1, i).equals("("))) { //an invalid operator is first or after right paren
                    Log.d(TAG,"Invalid Input 2");
                    finalEquation = new String[]{};
                    return false;

                } else if (i > 0 && numerics.contains(display.substring(i - 1, i))) { //thing before it is not an operator
                    equation.add(num);
                    equation.add(symbol);
                    num = "";
                    i++;
                } else if (i > 0 && operands.contains(display.substring(i - 1, i))) { //thing before it is not an operator
                    equation.add(symbol);
                    i++;
                } else if (i > 0 && display.substring(i - 1, i).equals(")")) { //after a right paren
                    equation.add(symbol);
                    i++;
                } else{
                    Log.d(TAG,"Invalid Input 3");
                    finalEquation = new String[]{};
                    return false;
                }

            } else if (symbol.equals(")")) {
                if (i==0 || operators.contains(display.substring(i - 1, i)) || display.substring(i - 1, i).equals("(") || numRParen >= numLParen) {
                    Log.d(TAG,"Invalid Input 4");
                    finalEquation = new String[]{};
                    return false;
                } else{
                    if (num.length()>0){ //thing before is num -> other option: ))
                        equation.add(num);
                        num="";
                    }
                    equation.add(symbol);
                    numRParen+=1;
                    i++;
                }
            } else if (symbol.equals("(")){
                if (num.length()>0){ //thing before is num -> other option: ))
                    equation.add(num);
                    equation.add("*");
                    num="";
                }
                equation.add(symbol);
                numLParen+=1;
                i++;
            }
            else if(display.endsWith("-")||display.endsWith("+")||display.endsWith("*")||display.endsWith("/")||display.endsWith("^")){
                Toast.makeText(this, "not a valid equation", Toast.LENGTH_SHORT).show();
            }
            else {
                Log.d(TAG,"Invalid Input 5");
                finalEquation = new String[]{};
                return false;
            }

        }
        if (!num.equals("")){
            equation.add(num);
        } else if (operators.contains(equation.get(equation.size()-1))){
            Log.d(TAG,"Invalid Input 6");
            finalEquation = new String[]{};
            return false;
        }
        if (numLParen!=numRParen){
            Log.d(TAG,"Invalid Input 7");
            finalEquation = new String[]{};
            return false;
        }
        infixEq=equation;
        Log.d(TAG, "infix at the end of parseString(): "+printInfixEq());
        finalEquation = new String[equation.size()];
        for (i = 0; i<equation.size();i++){
            finalEquation[i]=equation.get(i);
        }
        if (!hasNum){
            finalEquation = new String[]{};
            return false;
        }
        return true;


    }

    public void onBackspace(View v) {
        ArrayList<String> operators = new ArrayList<String>(Arrays.asList("+", "-", "/", "*", "^"));
        ArrayList<String> numerics = new ArrayList<String>(Arrays.asList(".", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"));
        String symbolBefore = "";
        if (display.length() > 0) {
            String trigCheck="";
            String symbol = display.substring(display.length() - 1, display.length());

            if (display.length() > 1) {
                symbolBefore = display.substring(display.length() - 2, display.length() - 1);
            }
            if (display.length() > 3) {
                trigCheck = display.substring(display.length() - 4, display.length());
            }

            if (numerics.contains(symbol)) {
                display = display.substring(0, display.length() - 1);
                if (symbol.equals(".")) {
                    //decimal = false;
                }

            } else if (operators.contains(symbol)) {
                display = display.substring(0, display.length() - 1);
                //remove symbol from equation
                //infixEq.remove(infixEq.size() - 1);

                //if thing before was number, move back to curNum and remove from stack
            } else if (trigCheck.equals("sin(") || trigCheck.equals("cos(") || trigCheck.equals("tan(")||trigCheck.equals("log(")) { //the symbol is trig
                display = display.substring(0, display.length() - 4);
                //infixEq.remove(infixEq.size() - 1); //remove left parenthesis
                numLeftParen -= 1;
                //infixEq.remove(infixEq.size() - 1); //remove trig
            } else if (symbol.equals(")")) {
                display = display.substring(0, display.length() - 1);
                //only thing that can precede it is a number
                //infixEq.remove(infixEq.size() - 1);
                //curNum = infixEq.get(infixEq.size() - 1);
                //infixEq.remove(infixEq.size() - 1);
                numRightParen -= 1;
            } else if (symbol.equals("(")) {
                display = display.substring(0, display.length() - 1);
                //check display versus infixEq for whether multiplication was implicit
                //infixEq.remove(infixEq.size() - 1);
                numLeftParen -= 1;
                if (symbolBefore.equals("")) {
                    //display = display.substring(0, display.length() - 1);
                    //infixEq.remove(infixEq.size() - 1);
                    isFirst = true;
                }
            } else if (symbol.equals("x")){
                display = display.substring(0, display.length() - 1);
                //check display versus infixEq for whether multiplication was implicit
                //infixEq.remove(infixEq.size() - 1);
                if (symbolBefore.equals("")) {
                    //display = display.substring(0, display.length() - 1);
                    //infixEq.remove(infixEq.size() - 1);
                    isFirst = true;

                }
            }
            if (display.length() == 0) {
                isFirst = true;
            }
            TextView tv = (TextView) findViewById(R.id.display);
            tv.setText(display);
        }

    }

    /**************************************
     *
     * Printing functions for testing
     *
     * ************************************/
    public String printInfixEq(){
        String tmp="";
        for (int i = 0; i<infixEq.size();i++){
            tmp+= infixEq.get(i);
            if (infixEq.get(i).equals("")){
                tmp+=" _ ";
            }
        }
        return tmp;
    }

    public String printArray(String[] array){
        String tmp="";
        for (int i = 0; i<array.length;i++){
            tmp+= array[i];
            if (array[i].equals("")){
                tmp+=" _ ";
            }
        }
        return tmp;
    }


    /**************************
     *
     * Enter- for normal calculator
     *
     *****************************/
    public void enter(View v) {
        Log.d(TAG, "is this valid: "+checkString());
        Log.d(TAG,"finalEquation: "+printArray(finalEquation));
        Log.d(TAG,"infixEq: "+ printInfixEq());
        double ans=0;
        if (checkString() && infixEq.contains("x")){

        }
        else if (checkString()){
            ans=compute(parseString());
            TextView tv = (TextView) findViewById(R.id.display);
            tv.setText(Double.toString(ans));

            Log.d(TAG, "infixEq1: " + printInfixEq());
            Log.d(TAG, "is this valid: " + checkString());
            Log.d(TAG, "finalEquation: " + printArray(finalEquation));
            Log.d(TAG, "infixEq2: " + printInfixEq());

            history += display;
            if (!curNum.equals("")) {
                infixEq.add(curNum);
            }
            postFix = parseString();
            curNum = "";
            String newEqn = history;
            oldEqns.add(newEqn);
            history = "";
            infixEq = new ArrayList<String>();
            numLeftParen = 0;
            numRightParen = 0;
        }
        else if(display.endsWith("-")||display.endsWith("+")||display.endsWith("*")||display.endsWith("/")||display.endsWith("^")){
            Toast.makeText(this, "not a valid equation", Toast.LENGTH_SHORT).show();

        }
        else{
            Toast.makeText(this, "not a valid equation", Toast.LENGTH_SHORT).show();
        }


    }


    /******************************************
     * Does calculation on postfix String[]
     *
     *
     ******************************************/
    public double compute(String[] postFix) throws IllegalArgumentException {
        try {
            double answer = 0;
            double result;
            Deque<Double> stack = new ArrayDeque<Double>();
            for (String item : postFix) {
                if (item != null) {
                    try {
                        double num = Double.parseDouble(item);
                        stack.addFirst(num);
                    } catch (NumberFormatException nfe) {
                        if (item.equals("\u0065")){
                            double num = Math.E;
                            stack.addFirst(num);
                        } else if (item.equals("\u03C0")){
                            double num = Math.PI;
                            stack.addFirst(num);
                        } else if (item.equals("+")) {
                            result = stack.removeFirst() + stack.removeFirst();
                            stack.addFirst(result);
                        } else if (item.equals("-")) {
                            double num2 = stack.removeFirst();
                            double num1 = stack.removeFirst();
                            result = num1 - num2;
                            stack.addFirst(result);
                        } else if (item.equals("*")) {
                            result = stack.removeFirst() * stack.removeFirst();
                            stack.addFirst(result);
                        } else if (item.equals("/")) {
                            double num2 = stack.removeFirst();
                            double num1 = stack.removeFirst();
                            result = num1 / num2;
                            stack.addFirst(result);
                        } else if (item.equals("^")) {
                            double num2 = stack.removeFirst();
                            double num1 = stack.removeFirst();
                            result = Math.pow(num1, num2);
                            stack.addFirst(result);
                        } else if (item.equals("sin")) {
                            result = Math.sin(stack.removeFirst());
                            stack.addFirst(result);
                        } else if (item.equals("cos")) {
                            result = Math.cos(stack.removeFirst());
                            stack.addFirst(result);
                        } else if (item.equals("tan")) {
                            result = Math.tan(stack.removeFirst());
                            stack.addFirst(result);
                        } else if (item.equals("log")){
                            Log.d(TAG, "compute a log");
                            result = Math.log(stack.removeFirst());
                            stack.addFirst(result);
                        }
                        else {
                            Log.d(TAG, "There is an invalid sign going into postfix");
                        }
                    }
                }
            }
            answer = stack.removeFirst();
            if (stack.isEmpty()) {
                return answer;
            } else {
                Toast.makeText(this, "Not a valid expression", Toast.LENGTH_SHORT).show();
                return 0;
            }
        }
        catch (IllegalArgumentException e1){
            Log.d(TAG, "Illegal Argument Exception)");
            return 0;
        }

    }

    /*******************************************************************************
     * Postfix converter
     * Converts the infixString ArrayList<String> to a postfix String[]
     * This method and helper methods based off of code from
     * http://www.dreamincode.net/forums/topic/305743-parsing-functions-in-postfix/
     *
     **********************************************************************************/
    public String[] parseString() {
        Log.d(TAG,"infixEq: "+ printInfixEq());
        Log.d(TAG, "input String: "+display);
        ArrayList postfixEquation = new ArrayList();
        Stack stack = new Stack();
        String curNum = "";     // Holds current number
        String curToken = "";   // Holds current token
        String curOp = "";      //Holds current operator or function

        for (int i = 0; i < infixEq.size(); i++) {
            curToken = (String)infixEq.get(i);
            if (isNumber(curToken))     //If the current token is a number
            {
                curNum += curToken;     //Add it to the curNumber string
                if (!curOp.isEmpty())    // There is an operator or function in curOp
                {
                    pushToStack(curOp, stack, postfixEquation); // Push it onto the stack
                    curOp = ""; // Reset curOp
                }
            } else{                     // Not a number

                if (!curNum.isEmpty())               // If there is a number in curNum
                {
                    postfixEquation.add(curNum);    // Add the current number to the postfix string
                    curNum = "";                    // Reset curNum
                }
                if (curToken.equals("("))    // If an opening parenthesis is encountered
                {
                    if(!curOp.equals("")) {  // Push the current operator or function onto the stack
                        stack.push(curOp);
                        // Reset curOp
                        curOp = "";
                    }
                    stack.push(curToken);   // Push opening parenthesis onto stack

                } else if (curToken.equals(")")) {
                    while (!stack.empty()) {   // Pop everything off the stack until a left parenthesis is encountered

                        if (stack.peek().equals("(")) {
                            stack.pop(); // Discard the opening parenthesis
                            if (!stack.empty()&& (stack.peek().equals("sin") ||stack.peek().equals("cos") ||stack.peek().equals("tan") || stack.peek().equals("log"))){ //if trig, add to postfix
                                postfixEquation.add(stack.pop());
                            }
                            break;
                        }
                        postfixEquation.add(stack.pop());
                    }
                }
                //This automatically pushes operators onto the stack. This is to avoid something like 4+sin(45) coming out as 4 45 +sin
                else if (curToken.equals("*")) {
                    pushToStack(curToken, stack, postfixEquation);
                }
                else if (curToken.equals("/")) {
                    pushToStack(curToken, stack, postfixEquation);
                }
                else if (curToken.equals("+")) {
                    pushToStack(curToken, stack, postfixEquation);
                }
                else if (curToken.equals("-")) {
                    pushToStack(curToken, stack, postfixEquation);
                }
                else if (curToken.equals("^")) {
                    pushToStack(curToken, stack, postfixEquation);
                }
                else
                    curOp += curToken;
            }
        }
        if (!curNum.isEmpty()) postfixEquation.add(curNum);    // Add any remaining numbers to the equation

        if (!curOp.isEmpty())
            pushToStack(curOp, stack, postfixEquation); // Add any remaining operators or functions onto the stack
        while (!stack.empty())
            postfixEquation.add(stack.pop());   // Add remaining operators and functions to the equation
        String output = "";
        postFix = new String[postfixEquation.size()];
        for (int i = 0; i < postfixEquation.size(); i++) {
            output += (postfixEquation.get(i));
            postFix[i] = (String) postfixEquation.get(i);
        }
        Log.d(TAG, "postfix: "+output);
        return postFix;
    }

    //for implementing parseString
    public void pushToStack(String curOp, Stack stack, ArrayList postfixEquation ){
        if (curOp.equals("+") || curOp.equals("-")) {
            //if top of stack has higher presidence, pop off, add to postFix, and then push new op onto stack
            while (!stack.isEmpty() && (stack.peek().equals("*") || stack.peek().equals("/") || stack.peek().equals("^") || stack.peek().equals("-") || stack.peek().equals("+") )) {
                postfixEquation.add(stack.pop().toString());
            }
            stack.push(curOp);
        } else if (curOp.equals("*") || curOp.equals("/")) {
            while (!stack.isEmpty() && (stack.peek().equals("*") || stack.peek().equals("/") || stack.peek().equals("^") )) {
                postfixEquation.add(stack.pop().toString());
            }
            stack.push(curOp);
        } else if (curOp.equals("^")) {
            while (!stack.isEmpty() && (stack.peek().equals("^") )) {
                postfixEquation.add(stack.pop().toString());
            }
            stack.push(curOp);
        } else{
            Log.d(TAG, "we are in this case" +curOp);
            stack.push(curOp);
        }
    }


    //For implementing parseString
    public boolean isNumber(String currToken) {
        if (currToken.equals("x")||currToken.equals("\u0065")||currToken.equals("\u03C0")) {
            return true;
        } else {
            try {
                Double.parseDouble(currToken);
                Log.d(TAG, "it's a number!");
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    }


    /***************
     *
     * CLEAR function
     *
     ******************/
    public void clear(View v) {
        curAnswer = 0;
        curSign = "";
        display = "";
        curNum = "";
        history ="";
        isOperator=false;
        postFix = new String[50];
        infixEq = new ArrayList<String>();
        idxCount = 0;
        TextView tv = (TextView)findViewById(R.id.display);
        tv.setText("enter equation");
        isFirst=true;
        wasCleared=true;
        //wasEntered=true;
        operatorStack.clear();
        numLeftParen=0;
        numRightParen=0;
    }

    /***********************
     *
     * Other Activities
     *
     *************************/

    public void history(View v) {
        for (int i = 0; i < oldEqns.size(); i++) {
            Log.d("Helpppp", oldEqns.get(i));
        }

        Intent i = new Intent(this, com.example.raheem.derivemecrazy.HistoryActivity.class);
        i.putExtra("list", oldEqns);


        clear(v);
        startActivity(i);
    }
    public void graph(View v) {


        if(display.equals("")){
            Toast.makeText(this, "Please enter a valid equation", Toast.LENGTH_SHORT).show();
        } else {
            Intent i = new Intent(this, com.example.raheem.derivemecrazy.CalcGraph.class);
            if (checkString()) {
                if(display.contains("e")){
                    display = display.replace("e","2.7182818");
                }
                if (display.contains("\u03C0")){
                    display = display.replace("\u03C0","3.14159");
                }
                i.putExtra("display", display);
                history += display;
                if (!curNum.equals("")) {
                    infixEq.add(curNum);
                }
                postFix = parseString();
                curNum = "";
                String newEqn = history;
                oldEqns.add(newEqn);
                history = "";
                clear(v);
                startActivity(i);
            } else {
                Toast.makeText(this, "Invalid Equation", Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void calculate(View v) {
        if(display.equals("")){
            Toast.makeText(this, "Please enter a valid equation", Toast.LENGTH_SHORT).show();
        }
        else if(display.endsWith("-")||display.endsWith("+")||display.endsWith("*")||display.endsWith("/")||display.endsWith("^")){
            Toast.makeText(this, "not a valid equation", Toast.LENGTH_SHORT).show();
        }
        else {
            Log.d(TAG, "infixEq1: " + printInfixEq());
            Log.d(TAG, "is this valid: " + checkString());
            Log.d(TAG, "finalEquation: " + printArray(finalEquation));
            Log.d(TAG, "infixEq2: " + printInfixEq());
            TextView tv = (TextView) findViewById(R.id.display);
            history += display;
            if (!curNum.equals("")) {
                infixEq.add(curNum);
            }
            postFix = parseString();
            curNum = "";
            String newEqn = history;
            oldEqns.add(newEqn);
            history = "";
            infixEq = new ArrayList<String>();
            numLeftParen = 0;
            numRightParen = 0;

            Intent intent = new Intent(MainActivity.this, CalculateActivity.class);
            intent.putExtra("equation", postFix);
            intent.putExtra("display", display);
            clear(v);
            startActivity(intent);

        }
    }
}