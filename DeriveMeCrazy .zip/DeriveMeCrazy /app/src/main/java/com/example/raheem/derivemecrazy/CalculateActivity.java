package com.example.raheem.derivemecrazy;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayDeque;
import java.util.Deque;

public class CalculateActivity extends AppCompatActivity {

    private final static String TAG = CalculateActivity.class.getName();
    Spinner spinner;
    ArrayAdapter<CharSequence> adapter;
    TextView x;
    TextView a;
    TextView b;
    EditText editx;
    EditText edita;
    EditText editb;

    String[] postfixEq;
    String displayEq;
    String selected = "derivative";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);
        Bundle bundle = getIntent().getExtras();
        postfixEq = bundle.getStringArray("equation");
        displayEq = bundle.getString("display");
        TextView tv = (TextView) findViewById(R.id.equation);
        tv.setText(displayEq);

        spinner = (Spinner) findViewById(R.id.spinner);
        adapter = ArrayAdapter.createFromResource(this, R.array.EvalOptions, R.layout.support_simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        x = (TextView) findViewById(R.id.x);
        a = (TextView) findViewById(R.id.a);
        b = (TextView) findViewById(R.id.b);
        editx = (EditText) findViewById(R.id.editTextX);
        edita = (EditText) findViewById(R.id.editTexta);
        editb = (EditText) findViewById(R.id.editTextB);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selected = parent.getItemAtPosition(position).toString();
                if (position == 1) {
                    a.setVisibility(View.VISIBLE);
                    b.setVisibility(View.VISIBLE);
                    edita.setVisibility(View.VISIBLE);
                    editb.setVisibility(View.VISIBLE);
                    x.setVisibility(View.GONE);
                    editx.setVisibility(View.GONE);
                } else {
                    a.setVisibility(View.GONE);
                    b.setVisibility(View.GONE);
                    edita.setVisibility(View.GONE);
                    editb.setVisibility(View.GONE);
                    x.setVisibility(View.VISIBLE);
                    editx.setVisibility(View.VISIBLE);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    ;

    public void evaluate(View v) {
        Double ans;
        if (selected.equals("Derivative")) {
            Log.d(TAG, "got here");
            EditText val = (EditText) findViewById(R.id.editTextX);
            float value = Float.valueOf(val.getText().toString());
            ans = dfridr(value, .2, .05);


        } else if (selected.equals("Integral")) {
            EditText aStr = (EditText) findViewById(R.id.editTexta);
            EditText bStr = (EditText) findViewById(R.id.editTextB);
            float a = Float.valueOf(aStr.getText().toString());
            float b = Float.valueOf(bStr.getText().toString());

            ans = integrate(a, b, 2000);

        } else if (selected.equals("Function")) {
            EditText val = (EditText) findViewById(R.id.editTextX);
            float value = Float.valueOf(val.getText().toString());
            ans = compute(removeVariables(value));
        } else {
            ans = (double) -1;
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
        }
        TextView view = (TextView) findViewById(R.id.answer);
        String answer = Double.toString(ans);
        //DecimalFormat df = new DecimalFormat("#.########");
        //df.format(ans);
        //view.setText(df.format(ans));
        view.setText(answer);
    }


    //computes derivative using Ridder's method
    //from http://www.aip.de/groups/soe/local/numres/bookcpdf/c5-7.pdf
    public double dfridr(double x, double h, double err) {
        double CON = 1.4;
        double CON2 = (CON * CON);
        double BIG = 1.0e30;
        double NTAB = 10;
        double SAFE = 2.0;


        int i, j;
        double errt, fac, hh;
        double ans = -1;
        if (h == 0.0) Log.d(TAG, "h must be nonzero in dfridr.");
        //look at how matrix is made
        Double[][] a = new Double[(int) NTAB][(int) NTAB];
        for (i = 0; i < NTAB; i++) {
            for (j = 0; j < NTAB; j++) {
                a[i][j] = (double) 1;
            }
        }
        hh = h;
        a[0][0] = (compute(removeVariables(x + hh)) - compute(removeVariables(x - hh))) / (2.0 * hh);
        err = BIG;
        for (i = 1; i < NTAB; i++) {
            //Successive columns  in  the  Neville  tableau  will  go to  smaller stepsizes and  higher  orders of
            //extrapolation.
            hh /= CON;
            a[0][i] = (compute(removeVariables(x + hh)) - compute(removeVariables(x - hh))) / (2.0 * hh);
            //Try  new,  smaller  step- size.
            fac = CON2;
            for (j = 1; j <= i; j++) {
                //Compute  extrapolations  of  various  orders,  requiring no new function evaluations.
                a[j][i] = (a[j - 1][i] * fac - a[j - 1][i - 1]) / (fac - 1.0);
                fac = CON2 * fac;
                errt = Math.max(Math.abs(a[j][i] - a[j - 1][i]), Math.abs(a[j][i] - a[j - 1][i - 1]));

                //The error strategy is to compare each new extrapolation to one order lower, both at  the  present  stepsize  and  the  previous  one.
                if (errt <= err) {
                    //If error is decreased, save the improved answer.
                    err = errt;
                    ans = a[j][i];
                }
            }
            if (Math.abs(a[i][i] - a[i - 1][i - 1]) >= SAFE * (err)) break;
            //If higher  order  is  worse by  a  signicant  factor SAFE,  then quit  early.
        }

        return ans;
    }

    /**********************************************************************
     * Integrate f from a to b using the trapezoidal rule.
     * Increase N for more precision. ex: 1000
     **********************************************************************/
    public double integrate(double a, double b, int N) {
        if (a == b) {
            return 0;
        }

        double h = (b - a) / N;              // step size
        double sum = 0.5 * (compute(removeVariables(a)) + compute(removeVariables(b)));    // area
        for (int i = 1; i < N; i++) {
            double x = a + h * i;
            sum = sum + compute(removeVariables(x));
        }

        return sum * h;
    }


    //function to replace variables like x and e with their numerical values
    public String[] removeVariables(double x) {
        //Log.d(TAG, "begin rv: " + printPostfixEq(postfixEq));
        String[] tmp = new String[postfixEq.length];
        for (int i = 0; i < postfixEq.length; i++) {
            if (postfixEq[i].equals("x")) {
                tmp[i] = Double.toString(x);
            } else if (postfixEq[i].equals("\u0065")) {
                tmp[i] = Double.toString(Math.E);
            } else if (postfixEq[i].equals("\u03C0")) {
                tmp[i] = Double.toString(Math.E);
            } else {
                tmp[i] = postfixEq[i];
            }
        }
        //Log.d(TAG, "end rv: " + printPostfixEq(tmp));
        return tmp;
    }

    public String printPostfixEq(String[] thing) {
        String tmp = "";
        for (int i = 0; i < thing.length; i++) {
            //Log.d(TAG, "thing[" + i + "] = " + thing[i]);
            tmp += thing[i];
            if (thing[i].equals("")) {
                tmp += " _ ";
            }
        }
        return tmp;
    }


    /******************************************
     * Does calculation on postfix String[]
     ******************************************/
    public double compute(String[] postFix) throws IllegalArgumentException {
        try {
            double answer = 0;
            double result;
            Deque<Double> stack = new ArrayDeque<Double>();
            for (String item : postFix) {
                if (item != null) {
                    try {
                        double num = Double.parseDouble(item);
                        stack.addFirst(num);
                    } catch (NumberFormatException nfe) {
                        if (item.equals("\u0065")) {
                            double num = Math.E;
                            stack.addFirst(num);
                        } else if (item.equals("\u03C0")) {
                            double num = Math.PI;
                            stack.addFirst(num);
                        } else if (item.equals("+")) {
                            result = stack.removeFirst() + stack.removeFirst();
                            stack.addFirst(result);
                        } else if (item.equals("-")) {
                            double num2 = stack.removeFirst();
                            double num1 = stack.removeFirst();
                            result = num1 - num2;
                            stack.addFirst(result);
                        } else if (item.equals("*")) {
                            result = stack.removeFirst() * stack.removeFirst();
                            stack.addFirst(result);
                        } else if (item.equals("/")) {
                            double num2 = stack.removeFirst();
                            double num1 = stack.removeFirst();
                            result = num1 / num2;
                            stack.addFirst(result);
                        } else if (item.equals("^")) {
                            double num2 = stack.removeFirst();
                            double num1 = stack.removeFirst();
                            result = Math.pow(num1, num2);
                            stack.addFirst(result);
                        } else if (item.equals("sin")) {
                            result = Math.sin(stack.removeFirst());
                            stack.addFirst(result);
                        } else if (item.equals("cos")) {
                            result = Math.cos(stack.removeFirst());
                            stack.addFirst(result);
                        } else if (item.equals("tan")) {
                            result = Math.tan(stack.removeFirst());
                            stack.addFirst(result);
                        } else if (item.equals("log")) {
                            Log.d(TAG, "compute a log");
                            result = Math.log(stack.removeFirst());
                            stack.addFirst(result);
                        } else {
                            Log.d(TAG, "There is an invalid sign going into postfix");
                        }
                    }
                }
            }
            answer = stack.removeFirst();
            if (stack.isEmpty()) {
                return answer;
            } else {
                Log.d(TAG, "top of stack: "+ stack.peek());
                Toast.makeText(this, "Not a valid expression", Toast.LENGTH_SHORT).show();
                return 0;
            }
        } catch (IllegalArgumentException e1) {
            Log.d(TAG, "Illegal Argument Exception)");
            return 0;
        }

    }
}

